let orderFood = new Promise((resolve, reject) => {
  

  if (false) {//true
    resolve("Here’s your burger!");
  } else {
    reject("Sorry, we're out of burgers.");
  }
});

orderFood
  .then((message) => console.log(message))   // If resolved
  .catch((error) => console.log(error));     // If rejected
