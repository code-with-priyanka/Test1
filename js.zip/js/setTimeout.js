console.log("first");

console.log("two");



console.log("four");
setInterval(function(){
    console.log("five")
},3000);

setTimeout(function(){
    console.log("three");
},4000);
