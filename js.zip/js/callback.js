function stud(name,rollno)
{
   console.log(name);
   rollno(23);
   rollno(34);
   rollno(38);
   rollno(31);

}
function rollno(r){
    console.log(r);
}
stud('piya',rollno);