console.log("piya");
setTimeout(function(){console.log("Butterfly")},2000)
setInterval(function(){console.log("Mukund")},3000)