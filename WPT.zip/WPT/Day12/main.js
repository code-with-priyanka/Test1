const a = require('./add.js')

console.log(a.add(2, 2))