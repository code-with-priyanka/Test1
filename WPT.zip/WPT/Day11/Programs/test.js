function add (a , b) { return a+b ; }
add(23,45)
save test.js