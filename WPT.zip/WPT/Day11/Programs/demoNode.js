console.log("From Node JS ");
console.log("From Node JS ");
console.log("From Node JS ");


let data = "";//input user command prompt

// use different module

//js html 