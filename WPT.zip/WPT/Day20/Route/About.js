import React from "react";

const About = () => {
    return (
        <div style={{ textAlign: "center", maxWidth: "600px" }}>
            <h2 style={{ color: "#2c3e50" }}>About Us</h2>
            <p style={{ fontSize: "18px", fontWeight: "bold" }}>
               IET Information 
               
                
            </p>
        </div>
    );
};

export default About;