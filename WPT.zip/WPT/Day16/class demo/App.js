import logo from './logo.svg';
import './App.css';

import ParentComponent from './ParentComponent'

import FromViewToComp from './FromViewToComp';
function App() {
  return (
    <div className="App">

      <ParentComponent></ParentComponent>
    </div>
  );
}
//
export default App;
