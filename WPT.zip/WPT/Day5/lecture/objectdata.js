const emp = {
    fName: "A",
    salary: 23456
};

const person = new Object(
    {
        firstName: "John",
        lastName: "Doe",
        age: 50,
        eyeColor: "blue",

        getData: function () {
            console.log();
        }
    });

person.doj = "";
person.getData();
console.log(person);

console.log(person.firstName);

class demo {





}