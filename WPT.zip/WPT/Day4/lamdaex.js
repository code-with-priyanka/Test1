function add(a, b) {

    return (a + b);
}
console.log(add(12, 12));

let s = (a, b) => a + b   //lamda function is defined 
// and assigned to variable s

let v = s(12, 10)
console.log(v);

console.log(s(12, 10))   //function is called

