// Function Com 
function Custom() {
  return (
    <p>
      Data  From Own Function
    </p>
  );
}

export default Custom;
