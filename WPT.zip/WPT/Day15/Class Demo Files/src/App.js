import logo from './logo.svg';
import './App.css';
import Calulator from './Calculation';

function App() {
  return (
    <div className="App">
      <Calulator num1="12" num2="23"></Calulator>
    </div>
  );
}
//
export default App;
