
function MyFunction() {

    return ("<h1>Data From myFunction</h1> ");

}

export default MyFunction;
